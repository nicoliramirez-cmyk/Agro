let plantas = [];
let solos = [];
let tiposPlantas = ["Arvore", "Milho", "Soja"];
let plantaSelecionada = "Arvore";

let maxPlantas = 15;
let pontuacao = 0;
let chuva = false;

let gotas = [];
let nuvens = [];
let pragas = [];

let jogoFinalizado = false;
let telaInicio = true;

let tempo = 60 * 30;

// ===============================
// MÚSICA (ANIMADA)
// ===============================

let synth;
let tocandoMusica = false;
let indiceNota = 0;

let melodia = [
  "C4","E4","G4","C5",
  "E5","G5","E5","C5",
  "D4","F4","A4","D5",
  "F5","A5","F5","D5",
  "G4","B4","D5","G5",
  "D5","B4","G4","E4"
];

// ===============================

function setup() {
  createCanvas(700, 500);
  textFont("Arial");

  synth = new p5.PolySynth();

  for (let i = 0; i < 5; i++) {
    solos.push({
      y: 400 - i * 20,
      qualidade: random(60, 100)
    });
  }

  for (let i = 0; i < 4; i++) {
    nuvens.push({
      x: random(width),
      y: random(40, 120),
      vx: random(0.3, 0.8)
    });
  }

  criarBotoes();
}

// ===============================
// BOTÕES
// ===============================

function criarBotoes() {
  for (let i = 0; i < tiposPlantas.length; i++) {
    let btn = createButton(tiposPlantas[i]);
    btn.position(20 + i * 100, 20);

    btn.mousePressed(() => {
      plantaSelecionada = tiposPlantas[i];
    });
  }

  let reiniciar = createButton("Reiniciar");
  reiniciar.position(20, 60);
  reiniciar.mousePressed(reiniciarJogo);
}

// ===============================
// LOOP PRINCIPAL
// ===============================

function draw() {

  if (telaInicio) {
    desenharTelaInicial();
    return;
  }

  background(135, 206, 235);

  tocarMusica();

  if (!jogoFinalizado) {

    desenharNuvens();
    desenharSolo();
    desenharPlantas();
    desenharPragas();
    desenharInterface();

    if (chuva) gerarChuva();

    for (let s of solos) {
      s.qualidade += 0.01;
      s.qualidade = constrain(s.qualidade, 0, 100);
    }

    if (frameCount % 120 === 0) {
      pragas.push({
        x: random(width),
        y: random(320, 400),
        tamanho: 15
      });
    }

    tempo--;

    if (tempo <= 0 || plantas.length >= maxPlantas) {
      jogoFinalizado = true;
    }

  } else {
    telaFim();
  }
}

// ===============================
// TELA INICIAL
// ===============================

function desenharTelaInicial() {

  background(180, 255, 180);
  textAlign(CENTER);

  fill(0);
  textSize(34);
  text("AGRO DESAFIO", width / 2, 80);

  textSize(18);
  text("OBJETIVO", width / 2, 130);

  textSize(15);
  text(
    "Plante e cuide do solo para alcançar a maior pontuação possível.",
    width / 2,
    170
  );

  text(
    "INSTRUÇÕES:\n\n" +
    "- Escolha uma planta\n" +
    "- Clique no solo para plantar\n" +
    "- Pressione C para chuva\n" +
    "- Evite pragas e degradação\n" +
    "- O jogo dura 30 segundos",
    width / 2,
    270
  );

  fill(50, 150, 50);
  rect(width / 2 - 120, 410, 240, 50, 10);

  fill(255);
  textSize(20);
  text("CLIQUE PARA COMEÇAR", width / 2, 443);
}

// ===============================
// MÚSICA ANIMADA
// ===============================

function tocarMusica() {
  if (!tocandoMusica) return;

  if (frameCount % 8 === 0) {
    synth.play(melodia[indiceNota], 0.5, 0, 0.2);

    indiceNota++;
    if (indiceNota >= melodia.length) indiceNota = 0;
  }
}

// ===============================
// ELEMENTOS VISUAIS
// ===============================

function desenharNuvens() {
  fill(255);
  noStroke();

  for (let n of nuvens) {
    ellipse(n.x, n.y, 80, 50);
    ellipse(n.x + 30, n.y + 10, 60, 40);

    n.x += n.vx;
    if (n.x > width + 50) n.x = -50;
  }
}

function desenharSolo() {
  for (let s of solos) {
    let cor = map(s.qualidade, 0, 100, 60, 139);

    fill(139, cor, 19);
    rect(0, s.y, width, 20);

    fill(0);
    textSize(12);
    text("Solo: " + round(s.qualidade) + "%", 10, s.y + 14);
  }
}

// ===============================
// PLANTAS
// ===============================

function desenharPlantas() {
  for (let p of plantas) {
    let s = solos[p.soloIndex];

    if (p.tamanho < p.tamanhoMax) {
      let crescimento = (chuva ? 0.4 : 0.2) * (s.qualidade / 100);
      p.tamanho += crescimento;
    }

    if (p.tipo === "Arvore") fill(34, 139, 34);
    else if (p.tipo === "Milho") fill(255, 215, 0);
    else fill(218, 165, 32);

    ellipse(p.x, p.y, p.tamanho);
  }
}

// ===============================
// PRAGAS
// ===============================

function desenharPragas() {
  fill(0);

  for (let i = pragas.length - 1; i >= 0; i--) {
    let p = pragas[i];

    ellipse(p.x, p.y, p.tamanho);

    for (let planta of plantas) {
      let d = dist(p.x, p.y, planta.x, planta.y);

      if (d < planta.tamanho / 2 + p.tamanho / 2) {
        planta.tamanho = max(planta.tamanho - 0.5, 0);
      }
    }
  }
}

// ===============================
// CHUVA
// ===============================

function gerarChuva() {
  if (frameCount % 2 === 0) {
    for (let i = 0; i < 10; i++) {
      gotas.push({
        x: random(width),
        y: -10,
        vy: random(4, 8)
      });
    }
  }

  stroke(0, 0, 255);

  for (let g of gotas) {
    line(g.x, g.y, g.x, g.y + 10);
    g.y += g.vy;
  }

  gotas = gotas.filter(g => g.y < height);

  for (let s of solos) {
    s.qualidade = constrain(s.qualidade + 0.2, 0, 100);
  }
}

// ===============================
// INTERFACE
// ===============================

function desenharInterface() {
  fill(0);
  noStroke();
  textSize(14);

  text("Plantas: " + plantas.length + "/" + maxPlantas, 420, 20);
  text("Selecionada: " + plantaSelecionada, 420, 40);
  text("Pontuação: " + pontuacao, 420, 60);
  text("Chuva: " + (chuva ? "SIM" : "NÃO"), 420, 80);
  text("Tempo: " + floor(tempo / 60) + "s", 420, 100);
}

// ===============================
// CONTROLES
// ===============================

function mousePressed() {

  if (telaInicio) {
    telaInicio = false;
    userStartAudio();
    tocandoMusica = true;
    return;
  }

  if (jogoFinalizado) return;

  let soloIndex = -1;

  for (let i = 0; i < solos.length; i++) {
    if (mouseY > solos[i].y && mouseY < solos[i].y + 20) {
      soloIndex = i;
      break;
    }
  }

  if (soloIndex !== -1) {
    plantas.push({
      x: mouseX,
      y: mouseY,
      tipo: plantaSelecionada,
      tamanho: 0,
      tamanhoMax: plantaSelecionada === "Arvore" ? 30 : 20,
      soloIndex
    });

    solos[soloIndex].qualidade -= plantaSelecionada === "Arvore" ? 5 : 10;

    pontuacao += 10;
  }
}

function keyPressed() {
  if (key === "C" || key === "c") chuva = !chuva;
  if (key === "R" || key === "r") reiniciarJogo();
}

// ===============================
// REINICIAR
// ===============================

function reiniciarJogo() {
  plantas = [];
  gotas = [];
  pragas = [];
  pontuacao = 0;
  tempo = 60 * 30;
  jogoFinalizado = false;
  chuva = false;
  telaInicio = true;
}

// ===============================
// TELA FINAL
// ===============================

function telaFim() {

  background(220, 255, 220);
  textAlign(CENTER);

  fill(0);
  textSize(28);
  text("FIM DE JOGO", width / 2, 100);

  let media = 0;
  for (let s of solos) media += s.qualidade;
  media /= solos.length;

  let resultado =
    pontuacao > 150 && media > 50
      ? "Excelente!"
      : pontuacao > 100
      ? "Bom trabalho!"
      : "Precisa melhorar!";

  textSize(18);
  text("Pontuação: " + pontuacao, width / 2, 180);
  text("Solo médio: " + round(media) + "%", width / 2, 220);
  text(resultado, width / 2, 270);

  textSize(14);
  text("Pressione R para reiniciar", width / 2, 340);
}